﻿namespace BuggieBungalow_Pult
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainScreen));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.onGame = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.delay_4drinks = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.GM_range_4Drinks = new System.Windows.Forms.PictureBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.solve_beerglasses = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.delay_stoptanz = new System.Windows.Forms.Label();
            this.GM_range_Stopptanz = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.trafficLight_stop = new System.Windows.Forms.Button();
            this.trafficLight_dance = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.delay_wasserhahn = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.GM_range_wasserhahn = new System.Windows.Forms.PictureBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.delay_sparkatchen = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.GM_range_sparkatsen = new System.Windows.Forms.PictureBox();
            this.button9 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.delay_separee = new System.Windows.Forms.Label();
            this.debuglabel = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.GM_range_Separee = new System.Windows.Forms.PictureBox();
            this.button26 = new System.Windows.Forms.Button();
            this.checkBox_moneyGun = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.DancingMoves_dance1 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.DancingMoves_dance3 = new System.Windows.Forms.Button();
            this.DancingMoves_dance2 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.delay_schichtplan = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.GM_range_workSchedules = new System.Windows.Forms.PictureBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.delay_jukebox = new System.Windows.Forms.Label();
            this.GM_range_jukebox = new System.Windows.Forms.PictureBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.preGame = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.CustomPacket = new System.Windows.Forms.TextBox();
            this.button_SendCustomPacket = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.PacketsSent_label = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.NodeResync_label = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.COMLog = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.NetChannel_label = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.SelfRepairs_label = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.CorruptPacket_label = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lastPacket_label = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox_separeePreFinalColor = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.MoneyGunDelay = new System.Windows.Forms.NumericUpDown();
            this.button19 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.dataGridRiddles = new System.Windows.Forms.DataGridView();
            this.Debug = new System.Windows.Forms.Label();
            this.groupBoxElectronicsSettings = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.COMportsList = new System.Windows.Forms.ComboBox();
            this.refreshCOM = new System.Windows.Forms.Button();
            this.ButtonCOM = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.masterNodeHealth = new System.Windows.Forms.Label();
            this.TotalPacket_label = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Music_finale = new System.Windows.Forms.Button();
            this.Music_strip = new System.Windows.Forms.Button();
            this.Music_Atmo2 = new System.Windows.Forms.Button();
            this.Music_Stopptanz = new System.Windows.Forms.Button();
            this.Music_Atmo1 = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.SessionRunningTime = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.progressBar_musicChange = new System.Windows.Forms.ProgressBar();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.FadeAtStart_mins = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.checkBox_FadeAtStart = new System.Windows.Forms.CheckBox();
            this.checkBox_fadeEffect = new System.Windows.Forms.CheckBox();
            this.FadeAtStart_secs = new System.Windows.Forms.NumericUpDown();
            this.FadeEffect_delay = new System.Windows.Forms.NumericUpDown();
            this.label_nextSong_delay = new System.Windows.Forms.Label();
            this.label_nextSong = new System.Windows.Forms.Label();
            this.label_track = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label_PlaybackState = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.checkBox_manualControl = new System.Windows.Forms.CheckBox();
            this.playMusic = new System.Windows.Forms.Button();
            this.pauseMusic = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label41 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.onGame.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_4Drinks)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_Stopptanz)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_wasserhahn)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_sparkatsen)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_Separee)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_workSchedules)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_jukebox)).BeginInit();
            this.preGame.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoneyGunDelay)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRiddles)).BeginInit();
            this.groupBoxElectronicsSettings.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FadeAtStart_mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FadeAtStart_secs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FadeEffect_delay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.onGame);
            this.tabControl1.Controls.Add(this.preGame);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.HotTrack = true;
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.tabControl1.ItemSize = new System.Drawing.Size(100, 50);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(80, 3);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1472, 921);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.TabStop = false;
            // 
            // onGame
            // 
            this.onGame.AutoScroll = true;
            this.onGame.BackColor = System.Drawing.Color.Silver;
            this.onGame.Controls.Add(this.groupBox6);
            this.onGame.Controls.Add(this.label8);
            this.onGame.Controls.Add(this.label7);
            this.onGame.Controls.Add(this.groupBox7);
            this.onGame.Controls.Add(this.label6);
            this.onGame.Controls.Add(this.groupBox5);
            this.onGame.Controls.Add(this.label3);
            this.onGame.Controls.Add(this.groupBox10);
            this.onGame.Controls.Add(this.groupBox4);
            this.onGame.Controls.Add(this.groupBox11);
            this.onGame.Controls.Add(this.groupBox8);
            this.onGame.Location = new System.Drawing.Point(4, 4);
            this.onGame.Margin = new System.Windows.Forms.Padding(4);
            this.onGame.Name = "onGame";
            this.onGame.Size = new System.Drawing.Size(1464, 863);
            this.onGame.TabIndex = 2;
            this.onGame.Text = "Raumsteuerung";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.LightGray;
            this.groupBox6.Controls.Add(this.delay_4drinks);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.GM_range_4Drinks);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.solve_beerglasses);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox6.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(20, 44);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(1439, 107);
            this.groupBox6.TabIndex = 35;
            this.groupBox6.TabStop = false;
            this.groupBox6.Enter += new System.EventHandler(this.groupBox6_Enter);
            // 
            // delay_4drinks
            // 
            this.delay_4drinks.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_4drinks.Location = new System.Drawing.Point(1133, 79);
            this.delay_4drinks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_4drinks.Name = "delay_4drinks";
            this.delay_4drinks.Size = new System.Drawing.Size(66, 22);
            this.delay_4drinks.TabIndex = 74;
            this.delay_4drinks.Text = "?";
            this.delay_4drinks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.delay_4drinks.Click += new System.EventHandler(this.label48_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(1373, 17);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(28, 18);
            this.label42.TabIndex = 56;
            this.label42.Text = "Tür";
            // 
            // GM_range_4Drinks
            // 
            this.GM_range_4Drinks.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_4Drinks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_4Drinks.BackgroundImage")));
            this.GM_range_4Drinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_4Drinks.Location = new System.Drawing.Point(1136, 17);
            this.GM_range_4Drinks.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_4Drinks.Name = "GM_range_4Drinks";
            this.GM_range_4Drinks.Size = new System.Drawing.Size(63, 58);
            this.GM_range_4Drinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_4Drinks.TabIndex = 38;
            this.GM_range_4Drinks.TabStop = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Silver;
            this.button10.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.door;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button10.Location = new System.Drawing.Point(1348, 39);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(79, 53);
            this.button10.TabIndex = 55;
            this.button10.TabStop = false;
            this.button10.Tag = "preG_4drinks_door";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(8, 39);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 24);
            this.label12.TabIndex = 34;
            this.label12.Text = "4 Getränke";
            // 
            // solve_beerglasses
            // 
            this.solve_beerglasses.BackColor = System.Drawing.Color.Silver;
            this.solve_beerglasses.Location = new System.Drawing.Point(831, 17);
            this.solve_beerglasses.Margin = new System.Windows.Forms.Padding(4);
            this.solve_beerglasses.Name = "solve_beerglasses";
            this.solve_beerglasses.Size = new System.Drawing.Size(179, 69);
            this.solve_beerglasses.TabIndex = 10;
            this.solve_beerglasses.TabStop = false;
            this.solve_beerglasses.Tag = "4Drinks";
            this.solve_beerglasses.Text = "Rätsel lösen";
            this.solve_beerglasses.UseVisualStyleBackColor = false;
            this.solve_beerglasses.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1331, 10);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 25);
            this.label8.TabIndex = 37;
            this.label8.Text = "Sonstiges";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1106, 10);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 25);
            this.label7.TabIndex = 37;
            this.label7.Text = "Zustand / WiFi";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.LightGray;
            this.groupBox7.Controls.Add(this.delay_stoptanz);
            this.groupBox7.Controls.Add(this.GM_range_Stopptanz);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label13);
            this.groupBox7.Controls.Add(this.button30);
            this.groupBox7.Controls.Add(this.trafficLight_stop);
            this.groupBox7.Controls.Add(this.trafficLight_dance);
            this.groupBox7.Controls.Add(this.button22);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(20, 273);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(1439, 107);
            this.groupBox7.TabIndex = 37;
            this.groupBox7.TabStop = false;
            // 
            // delay_stoptanz
            // 
            this.delay_stoptanz.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_stoptanz.Location = new System.Drawing.Point(1133, 81);
            this.delay_stoptanz.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_stoptanz.Name = "delay_stoptanz";
            this.delay_stoptanz.Size = new System.Drawing.Size(66, 22);
            this.delay_stoptanz.TabIndex = 76;
            this.delay_stoptanz.Text = "?";
            this.delay_stoptanz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GM_range_Stopptanz
            // 
            this.GM_range_Stopptanz.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_Stopptanz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_Stopptanz.BackgroundImage")));
            this.GM_range_Stopptanz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_Stopptanz.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_Stopptanz.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_Stopptanz.Name = "GM_range_Stopptanz";
            this.GM_range_Stopptanz.Size = new System.Drawing.Size(63, 58);
            this.GM_range_Stopptanz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_Stopptanz.TabIndex = 40;
            this.GM_range_Stopptanz.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(831, 78);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(125, 18);
            this.label20.TabIndex = 35;
            this.label20.Text = "(🢡 Sparkästchen)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, 39);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 24);
            this.label13.TabIndex = 34;
            this.label13.Text = "Stopptanz";
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Silver;
            this.button30.Location = new System.Drawing.Point(175, 21);
            this.button30.Margin = new System.Windows.Forms.Padding(4);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(179, 69);
            this.button30.TabIndex = 20;
            this.button30.TabStop = false;
            this.button30.Tag = "TrafficLight_Start";
            this.button30.Text = "Ampel aktivieren";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // trafficLight_stop
            // 
            this.trafficLight_stop.BackColor = System.Drawing.Color.DarkRed;
            this.trafficLight_stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trafficLight_stop.ForeColor = System.Drawing.Color.Snow;
            this.trafficLight_stop.Location = new System.Drawing.Point(375, 21);
            this.trafficLight_stop.Margin = new System.Windows.Forms.Padding(4);
            this.trafficLight_stop.Name = "trafficLight_stop";
            this.trafficLight_stop.Size = new System.Drawing.Size(179, 69);
            this.trafficLight_stop.TabIndex = 12;
            this.trafficLight_stop.TabStop = false;
            this.trafficLight_stop.Tag = "TrafficLight_Stop";
            this.trafficLight_stop.Text = "Stop!";
            this.trafficLight_stop.UseVisualStyleBackColor = false;
            this.trafficLight_stop.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // trafficLight_dance
            // 
            this.trafficLight_dance.BackColor = System.Drawing.Color.DarkGreen;
            this.trafficLight_dance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trafficLight_dance.Location = new System.Drawing.Point(562, 21);
            this.trafficLight_dance.Margin = new System.Windows.Forms.Padding(4);
            this.trafficLight_dance.Name = "trafficLight_dance";
            this.trafficLight_dance.Size = new System.Drawing.Size(179, 69);
            this.trafficLight_dance.TabIndex = 11;
            this.trafficLight_dance.TabStop = false;
            this.trafficLight_dance.Tag = "TrafficLight_Dance";
            this.trafficLight_dance.Text = "Dance!";
            this.trafficLight_dance.UseVisualStyleBackColor = false;
            this.trafficLight_dance.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Silver;
            this.button22.Location = new System.Drawing.Point(831, 21);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(179, 53);
            this.button22.TabIndex = 11;
            this.button22.TabStop = false;
            this.button22.Tag = "TrafficLight_Solve";
            this.button22.Text = "Rätsel lösen";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(862, 10);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 25);
            this.label6.TabIndex = 36;
            this.label6.Text = "Fernauslösung";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LightGray;
            this.groupBox5.Controls.Add(this.delay_wasserhahn);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.GM_range_wasserhahn);
            this.groupBox5.Controls.Add(this.button8);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.button29);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(20, 502);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1439, 107);
            this.groupBox5.TabIndex = 37;
            this.groupBox5.TabStop = false;
            // 
            // delay_wasserhahn
            // 
            this.delay_wasserhahn.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_wasserhahn.Location = new System.Drawing.Point(1133, 78);
            this.delay_wasserhahn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_wasserhahn.Name = "delay_wasserhahn";
            this.delay_wasserhahn.Size = new System.Drawing.Size(66, 22);
            this.delay_wasserhahn.TabIndex = 78;
            this.delay_wasserhahn.Text = "?";
            this.delay_wasserhahn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(1373, 14);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(28, 18);
            this.label35.TabIndex = 52;
            this.label35.Text = "Tür";
            // 
            // GM_range_wasserhahn
            // 
            this.GM_range_wasserhahn.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_wasserhahn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_wasserhahn.BackgroundImage")));
            this.GM_range_wasserhahn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_wasserhahn.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_wasserhahn.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_wasserhahn.Name = "GM_range_wasserhahn";
            this.GM_range_wasserhahn.Size = new System.Drawing.Size(63, 58);
            this.GM_range_wasserhahn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_wasserhahn.TabIndex = 42;
            this.GM_range_wasserhahn.TabStop = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Silver;
            this.button8.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.door;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button8.Location = new System.Drawing.Point(1348, 36);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(79, 53);
            this.button8.TabIndex = 51;
            this.button8.TabStop = false;
            this.button8.Tag = "preG_wasserhahn_door";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(831, 78);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(150, 18);
            this.label18.TabIndex = 35;
            this.label18.Text = "(🢡 Geheimtür öffnen)";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Silver;
            this.button6.Location = new System.Drawing.Point(831, 21);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(179, 53);
            this.button6.TabIndex = 10;
            this.button6.TabStop = false;
            this.button6.Tag = "wasserhahn_solve";
            this.button6.Text = "Rätsel lösen\r\n";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Silver;
            this.button5.Location = new System.Drawing.Point(375, 21);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(179, 69);
            this.button5.TabIndex = 10;
            this.button5.TabStop = false;
            this.button5.Tag = "wasserhahn_enable";
            this.button5.Text = "Wasserhahn aktivieren";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Silver;
            this.button29.Location = new System.Drawing.Point(175, 21);
            this.button29.Margin = new System.Windows.Forms.Padding(4);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(179, 69);
            this.button29.TabIndex = 22;
            this.button29.TabStop = false;
            this.button29.Tag = "Telephone_ring";
            this.button29.Text = "Ring";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            this.button29.KeyUp += new System.Windows.Forms.KeyEventHandler(this.button29_KeyUp);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(8, 27);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(181, 62);
            this.label15.TabIndex = 34;
            this.label15.Text = "Sex-Hotline/\r\nWasserhahn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(405, 7);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 25);
            this.label3.TabIndex = 35;
            this.label3.Text = "Spielleitersteuerung";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox10.Controls.Add(this.delay_sparkatchen);
            this.groupBox10.Controls.Add(this.label37);
            this.groupBox10.Controls.Add(this.GM_range_sparkatsen);
            this.groupBox10.Controls.Add(this.button9);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Controls.Add(this.button17);
            this.groupBox10.Controls.Add(this.label14);
            this.groupBox10.Controls.Add(this.button16);
            this.groupBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox10.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(20, 388);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(1439, 107);
            this.groupBox10.TabIndex = 36;
            this.groupBox10.TabStop = false;
            // 
            // delay_sparkatchen
            // 
            this.delay_sparkatchen.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_sparkatchen.Location = new System.Drawing.Point(1133, 78);
            this.delay_sparkatchen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_sparkatchen.Name = "delay_sparkatchen";
            this.delay_sparkatchen.Size = new System.Drawing.Size(66, 22);
            this.delay_sparkatchen.TabIndex = 77;
            this.delay_sparkatchen.Text = "?";
            this.delay_sparkatchen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1373, 7);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(28, 18);
            this.label37.TabIndex = 54;
            this.label37.Text = "Tür";
            // 
            // GM_range_sparkatsen
            // 
            this.GM_range_sparkatsen.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_sparkatsen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_sparkatsen.BackgroundImage")));
            this.GM_range_sparkatsen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_sparkatsen.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_sparkatsen.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_sparkatsen.Name = "GM_range_sparkatsen";
            this.GM_range_sparkatsen.Size = new System.Drawing.Size(63, 58);
            this.GM_range_sparkatsen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_sparkatsen.TabIndex = 41;
            this.GM_range_sparkatsen.TabStop = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Silver;
            this.button9.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.door;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button9.Location = new System.Drawing.Point(1348, 29);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(79, 53);
            this.button9.TabIndex = 53;
            this.button9.TabStop = false;
            this.button9.Tag = "preG_Sparkastchen_door";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(831, 78);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(124, 18);
            this.label19.TabIndex = 35;
            this.label19.Text = "(🢡 WC Schlüssel)";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Silver;
            this.button17.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.button17.Location = new System.Drawing.Point(831, 21);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(179, 53);
            this.button17.TabIndex = 23;
            this.button17.TabStop = false;
            this.button17.Tag = "Sparkastchen_solve";
            this.button17.Text = "Rätsel lösen";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(8, 39);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(136, 24);
            this.label14.TabIndex = 34;
            this.label14.Text = "Sparkästchen";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Silver;
            this.button16.Location = new System.Drawing.Point(175, 21);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(179, 69);
            this.button16.TabIndex = 10;
            this.button16.TabStop = false;
            this.button16.Tag = "Sparkastchen_start";
            this.button16.Text = "Sparkästchen aktivieren";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LightGray;
            this.groupBox4.Controls.Add(this.delay_separee);
            this.groupBox4.Controls.Add(this.debuglabel);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.GM_range_Separee);
            this.groupBox4.Controls.Add(this.button26);
            this.groupBox4.Controls.Add(this.checkBox_moneyGun);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.DancingMoves_dance1);
            this.groupBox4.Controls.Add(this.button28);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.DancingMoves_dance3);
            this.groupBox4.Controls.Add(this.DancingMoves_dance2);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(20, 731);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(1439, 107);
            this.groupBox4.TabIndex = 38;
            this.groupBox4.TabStop = false;
            // 
            // delay_separee
            // 
            this.delay_separee.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_separee.Location = new System.Drawing.Point(1133, 79);
            this.delay_separee.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_separee.Name = "delay_separee";
            this.delay_separee.Size = new System.Drawing.Size(66, 22);
            this.delay_separee.TabIndex = 79;
            this.delay_separee.Text = "?";
            this.delay_separee.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // debuglabel
            // 
            this.debuglabel.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.debuglabel.Location = new System.Drawing.Point(940, 79);
            this.debuglabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.debuglabel.Name = "debuglabel";
            this.debuglabel.Size = new System.Drawing.Size(237, 22);
            this.debuglabel.TabIndex = 56;
            this.debuglabel.Text = ", countdown:";
            this.debuglabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(1382, 7);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 18);
            this.label27.TabIndex = 48;
            this.label27.Text = "Tür";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(1820, 528);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 18);
            this.label23.TabIndex = 47;
            this.label23.Text = "Auf";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1242, 82);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 18);
            this.label21.TabIndex = 46;
            this.label21.Text = "Aus";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1300, 82);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 18);
            this.label11.TabIndex = 45;
            this.label11.Text = "Weiss";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1271, 7);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 18);
            this.label10.TabIndex = 44;
            this.label10.Text = "Licht";
            // 
            // GM_range_Separee
            // 
            this.GM_range_Separee.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_Separee.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_Separee.BackgroundImage")));
            this.GM_range_Separee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_Separee.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_Separee.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_Separee.Name = "GM_range_Separee";
            this.GM_range_Separee.Size = new System.Drawing.Size(63, 58);
            this.GM_range_Separee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_Separee.TabIndex = 44;
            this.GM_range_Separee.TabStop = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Silver;
            this.button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(1230, 30);
            this.button26.Margin = new System.Windows.Forms.Padding(4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(57, 53);
            this.button26.TabIndex = 30;
            this.button26.TabStop = false;
            this.button26.Tag = "preG_Separee_off";
            this.button26.Text = "AUS";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // checkBox_moneyGun
            // 
            this.checkBox_moneyGun.AutoSize = true;
            this.checkBox_moneyGun.Checked = true;
            this.checkBox_moneyGun.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_moneyGun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_moneyGun.Location = new System.Drawing.Point(831, 80);
            this.checkBox_moneyGun.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox_moneyGun.Name = "checkBox_moneyGun";
            this.checkBox_moneyGun.Size = new System.Drawing.Size(119, 22);
            this.checkBox_moneyGun.TabIndex = 35;
            this.checkBox_moneyGun.Text = "mit MoneyGun";
            this.checkBox_moneyGun.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(8, 39);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 24);
            this.label17.TabIndex = 34;
            this.label17.Text = "Separee";
            // 
            // DancingMoves_dance1
            // 
            this.DancingMoves_dance1.BackColor = System.Drawing.Color.Fuchsia;
            this.DancingMoves_dance1.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.dance1;
            this.DancingMoves_dance1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.DancingMoves_dance1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DancingMoves_dance1.Location = new System.Drawing.Point(175, 22);
            this.DancingMoves_dance1.Margin = new System.Windows.Forms.Padding(4);
            this.DancingMoves_dance1.Name = "DancingMoves_dance1";
            this.DancingMoves_dance1.Size = new System.Drawing.Size(179, 69);
            this.DancingMoves_dance1.TabIndex = 12;
            this.DancingMoves_dance1.TabStop = false;
            this.DancingMoves_dance1.Tag = "Separee_r";
            this.DancingMoves_dance1.UseVisualStyleBackColor = false;
            this.DancingMoves_dance1.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Silver;
            this.button28.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.door;
            this.button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button28.Location = new System.Drawing.Point(1360, 29);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(79, 53);
            this.button28.TabIndex = 32;
            this.button28.TabStop = false;
            this.button28.Tag = "preG_Separee_door";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Location = new System.Drawing.Point(831, 21);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(179, 53);
            this.button3.TabIndex = 33;
            this.button3.TabStop = false;
            this.button3.Tag = "Separee_solve";
            this.button3.Text = "Rätsel lösen";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // DancingMoves_dance3
            // 
            this.DancingMoves_dance3.BackColor = System.Drawing.Color.Blue;
            this.DancingMoves_dance3.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.dance2;
            this.DancingMoves_dance3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.DancingMoves_dance3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DancingMoves_dance3.Location = new System.Drawing.Point(562, 22);
            this.DancingMoves_dance3.Margin = new System.Windows.Forms.Padding(4);
            this.DancingMoves_dance3.Name = "DancingMoves_dance3";
            this.DancingMoves_dance3.Size = new System.Drawing.Size(179, 69);
            this.DancingMoves_dance3.TabIndex = 14;
            this.DancingMoves_dance3.TabStop = false;
            this.DancingMoves_dance3.Tag = "Separee_b";
            this.DancingMoves_dance3.UseVisualStyleBackColor = false;
            this.DancingMoves_dance3.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // DancingMoves_dance2
            // 
            this.DancingMoves_dance2.BackColor = System.Drawing.Color.Green;
            this.DancingMoves_dance2.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.dance3;
            this.DancingMoves_dance2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.DancingMoves_dance2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DancingMoves_dance2.Location = new System.Drawing.Point(375, 22);
            this.DancingMoves_dance2.Margin = new System.Windows.Forms.Padding(4);
            this.DancingMoves_dance2.Name = "DancingMoves_dance2";
            this.DancingMoves_dance2.Size = new System.Drawing.Size(179, 69);
            this.DancingMoves_dance2.TabIndex = 13;
            this.DancingMoves_dance2.TabStop = false;
            this.DancingMoves_dance2.Tag = "Separee_g";
            this.DancingMoves_dance2.UseVisualStyleBackColor = false;
            this.DancingMoves_dance2.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Ivory;
            this.button2.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.lightbulb_regular;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1295, 30);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(57, 53);
            this.button2.TabIndex = 22;
            this.button2.TabStop = false;
            this.button2.Tag = "preG_Separee_w";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox11.Controls.Add(this.delay_schichtplan);
            this.groupBox11.Controls.Add(this.label34);
            this.groupBox11.Controls.Add(this.GM_range_workSchedules);
            this.groupBox11.Controls.Add(this.button7);
            this.groupBox11.Controls.Add(this.label26);
            this.groupBox11.Controls.Add(this.button18);
            this.groupBox11.Controls.Add(this.label16);
            this.groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox11.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(20, 617);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(1439, 107);
            this.groupBox11.TabIndex = 36;
            this.groupBox11.TabStop = false;
            // 
            // delay_schichtplan
            // 
            this.delay_schichtplan.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_schichtplan.Location = new System.Drawing.Point(1133, 79);
            this.delay_schichtplan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_schichtplan.Name = "delay_schichtplan";
            this.delay_schichtplan.Size = new System.Drawing.Size(66, 22);
            this.delay_schichtplan.TabIndex = 78;
            this.delay_schichtplan.Text = "?";
            this.delay_schichtplan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(1373, 9);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(28, 18);
            this.label34.TabIndex = 50;
            this.label34.Text = "Tür";
            // 
            // GM_range_workSchedules
            // 
            this.GM_range_workSchedules.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_workSchedules.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_workSchedules.BackgroundImage")));
            this.GM_range_workSchedules.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_workSchedules.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_workSchedules.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_workSchedules.Name = "GM_range_workSchedules";
            this.GM_range_workSchedules.Size = new System.Drawing.Size(63, 58);
            this.GM_range_workSchedules.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_workSchedules.TabIndex = 43;
            this.GM_range_workSchedules.TabStop = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Silver;
            this.button7.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.door;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button7.Location = new System.Drawing.Point(1348, 31);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(79, 53);
            this.button7.TabIndex = 49;
            this.button7.TabStop = false;
            this.button7.Tag = "preG_worksch_door";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(831, 81);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(211, 18);
            this.label26.TabIndex = 35;
            this.label26.Text = "(🢡 Schublade Tresorschlüssel)";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Silver;
            this.button18.Location = new System.Drawing.Point(831, 21);
            this.button18.Margin = new System.Windows.Forms.Padding(4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(179, 53);
            this.button18.TabIndex = 10;
            this.button18.TabStop = false;
            this.button18.Tag = "WorkingSchedules";
            this.button18.Text = "Rätsel lösen";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 39);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 24);
            this.label16.TabIndex = 34;
            this.label16.Text = "Schichtplan";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox8.Controls.Add(this.delay_jukebox);
            this.groupBox8.Controls.Add(this.GM_range_jukebox);
            this.groupBox8.Controls.Add(this.button14);
            this.groupBox8.Controls.Add(this.button15);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.button20);
            this.groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox8.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(20, 159);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(1439, 107);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            // 
            // delay_jukebox
            // 
            this.delay_jukebox.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delay_jukebox.Location = new System.Drawing.Point(1133, 81);
            this.delay_jukebox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.delay_jukebox.Name = "delay_jukebox";
            this.delay_jukebox.Size = new System.Drawing.Size(66, 22);
            this.delay_jukebox.TabIndex = 75;
            this.delay_jukebox.Text = "?";
            this.delay_jukebox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GM_range_jukebox
            // 
            this.GM_range_jukebox.BackColor = System.Drawing.Color.Transparent;
            this.GM_range_jukebox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GM_range_jukebox.BackgroundImage")));
            this.GM_range_jukebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GM_range_jukebox.Location = new System.Drawing.Point(1136, 21);
            this.GM_range_jukebox.Margin = new System.Windows.Forms.Padding(4);
            this.GM_range_jukebox.Name = "GM_range_jukebox";
            this.GM_range_jukebox.Size = new System.Drawing.Size(63, 58);
            this.GM_range_jukebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.GM_range_jukebox.TabIndex = 39;
            this.GM_range_jukebox.TabStop = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Silver;
            this.button14.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.button14.Location = new System.Drawing.Point(375, 18);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(179, 69);
            this.button14.TabIndex = 21;
            this.button14.TabStop = false;
            this.button14.Tag = "Jukebox_Fix";
            this.button14.Text = "Jukebox reparieren";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Silver;
            this.button15.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.button15.Location = new System.Drawing.Point(831, 21);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(179, 69);
            this.button15.TabIndex = 22;
            this.button15.TabStop = false;
            this.button15.Tag = "Jukebox_SolveSong";
            this.button15.Text = "Song überspringen";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 24);
            this.label1.TabIndex = 34;
            this.label1.Text = "Jukebox";
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Silver;
            this.button20.Location = new System.Drawing.Point(175, 18);
            this.button20.Margin = new System.Windows.Forms.Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(179, 69);
            this.button20.TabIndex = 10;
            this.button20.TabStop = false;
            this.button20.Tag = "Jukebox_Activate";
            this.button20.Text = "Jukebox aktivieren";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.GameMasterLaunchedRiddle);
            // 
            // preGame
            // 
            this.preGame.BackColor = System.Drawing.Color.LightGray;
            this.preGame.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.preGame.Controls.Add(this.groupBox3);
            this.preGame.Controls.Add(this.groupBox1);
            this.preGame.Controls.Add(this.groupBox16);
            this.preGame.Controls.Add(this.Debug);
            this.preGame.Controls.Add(this.groupBoxElectronicsSettings);
            this.preGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preGame.Location = new System.Drawing.Point(4, 4);
            this.preGame.Margin = new System.Windows.Forms.Padding(4);
            this.preGame.Name = "preGame";
            this.preGame.Padding = new System.Windows.Forms.Padding(4);
            this.preGame.Size = new System.Drawing.Size(1174, 863);
            this.preGame.TabIndex = 1;
            this.preGame.Text = "Einstellungen";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.CustomPacket);
            this.groupBox3.Controls.Add(this.button_SendCustomPacket);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.PacketsSent_label);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.NodeResync_label);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.COMLog);
            this.groupBox3.Controls.Add(this.label45);
            this.groupBox3.Controls.Add(this.NetChannel_label);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.SelfRepairs_label);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.CorruptPacket_label);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.lastPacket_label);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(8, 197);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(1450, 314);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Erweiterte Nutzung";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // CustomPacket
            // 
            this.CustomPacket.Location = new System.Drawing.Point(357, 245);
            this.CustomPacket.Margin = new System.Windows.Forms.Padding(4);
            this.CustomPacket.Name = "CustomPacket";
            this.CustomPacket.Size = new System.Drawing.Size(229, 26);
            this.CustomPacket.TabIndex = 34;
            // 
            // button_SendCustomPacket
            // 
            this.button_SendCustomPacket.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button_SendCustomPacket.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SendCustomPacket.Location = new System.Drawing.Point(596, 244);
            this.button_SendCustomPacket.Margin = new System.Windows.Forms.Padding(4);
            this.button_SendCustomPacket.Name = "button_SendCustomPacket";
            this.button_SendCustomPacket.Size = new System.Drawing.Size(148, 36);
            this.button_SendCustomPacket.TabIndex = 15;
            this.button_SendCustomPacket.TabStop = false;
            this.button_SendCustomPacket.Text = "Senden";
            this.button_SendCustomPacket.UseVisualStyleBackColor = false;
            this.button_SendCustomPacket.Click += new System.EventHandler(this.button_SendCustomPacket_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 247);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "Benutzerdefinierte Pakete senden";
            // 
            // PacketsSent_label
            // 
            this.PacketsSent_label.AutoSize = true;
            this.PacketsSent_label.Location = new System.Drawing.Point(1293, 34);
            this.PacketsSent_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PacketsSent_label.Name = "PacketsSent_label";
            this.PacketsSent_label.Size = new System.Drawing.Size(108, 20);
            this.PacketsSent_label.TabIndex = 33;
            this.PacketsSent_label.Text = "Keine Daten";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(1106, 34);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(147, 20);
            this.label25.TabIndex = 32;
            this.label25.Text = "Gesendete Pakete:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(19, 279);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(163, 20);
            this.label36.TabIndex = 11;
            this.label36.Text = "Letztes Paket (RAW):";
            // 
            // NodeResync_label
            // 
            this.NodeResync_label.AutoSize = true;
            this.NodeResync_label.Location = new System.Drawing.Point(1293, 109);
            this.NodeResync_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NodeResync_label.Name = "NodeResync_label";
            this.NodeResync_label.Size = new System.Drawing.Size(108, 20);
            this.NodeResync_label.TabIndex = 31;
            this.NodeResync_label.Text = "Keine Daten";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1107, 106);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(121, 20);
            this.label22.TabIndex = 30;
            this.label22.Text = "Node Re-syncs:";
            // 
            // COMLog
            // 
            this.COMLog.AcceptsReturn = true;
            this.COMLog.AcceptsTab = true;
            this.COMLog.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.COMLog.BackColor = System.Drawing.SystemColors.MenuText;
            this.COMLog.ForeColor = System.Drawing.Color.Ivory;
            this.COMLog.Location = new System.Drawing.Point(13, 31);
            this.COMLog.Margin = new System.Windows.Forms.Padding(4);
            this.COMLog.Multiline = true;
            this.COMLog.Name = "COMLog";
            this.COMLog.ReadOnly = true;
            this.COMLog.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.COMLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.COMLog.ShortcutsEnabled = false;
            this.COMLog.Size = new System.Drawing.Size(1089, 207);
            this.COMLog.TabIndex = 0;
            this.COMLog.TabStop = false;
            this.COMLog.TextChanged += new System.EventHandler(this.COMLog_TextChanged);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(369, 255);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(0, 20);
            this.label45.TabIndex = 29;
            // 
            // NetChannel_label
            // 
            this.NetChannel_label.AutoSize = true;
            this.NetChannel_label.Location = new System.Drawing.Point(1293, 133);
            this.NetChannel_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NetChannel_label.Name = "NetChannel_label";
            this.NetChannel_label.Size = new System.Drawing.Size(108, 20);
            this.NetChannel_label.TabIndex = 27;
            this.NetChannel_label.Text = "Keine Daten";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(1107, 130);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(119, 20);
            this.label39.TabIndex = 26;
            this.label39.Text = "Aktueller Kanal:";
            // 
            // SelfRepairs_label
            // 
            this.SelfRepairs_label.AutoSize = true;
            this.SelfRepairs_label.Location = new System.Drawing.Point(1293, 84);
            this.SelfRepairs_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SelfRepairs_label.Name = "SelfRepairs_label";
            this.SelfRepairs_label.Size = new System.Drawing.Size(108, 20);
            this.SelfRepairs_label.TabIndex = 25;
            this.SelfRepairs_label.Text = "Keine Daten";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(1107, 81);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(176, 20);
            this.label33.TabIndex = 24;
            this.label33.Text = "Master Selbstreparatur:";
            // 
            // CorruptPacket_label
            // 
            this.CorruptPacket_label.AutoSize = true;
            this.CorruptPacket_label.Location = new System.Drawing.Point(1293, 59);
            this.CorruptPacket_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CorruptPacket_label.Name = "CorruptPacket_label";
            this.CorruptPacket_label.Size = new System.Drawing.Size(108, 20);
            this.CorruptPacket_label.TabIndex = 21;
            this.CorruptPacket_label.Text = "Keine Daten";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(1107, 56);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(151, 20);
            this.label38.TabIndex = 20;
            this.label38.Text = "Verdorbene Pakete:";
            // 
            // lastPacket_label
            // 
            this.lastPacket_label.Location = new System.Drawing.Point(353, 279);
            this.lastPacket_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lastPacket_label.Name = "lastPacket_label";
            this.lastPacket_label.Size = new System.Drawing.Size(544, 25);
            this.lastPacket_label.TabIndex = 17;
            this.lastPacket_label.Text = "Keine Daten";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.comboBox_separeePreFinalColor);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.MoneyGunDelay);
            this.groupBox1.Controls.Add(this.button19);
            this.groupBox1.Controls.Add(this.button24);
            this.groupBox1.Controls.Add(this.button25);
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.button23);
            this.groupBox1.Controls.Add(this.button21);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(895, 9);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(563, 180);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Verschiedenes";
            // 
            // comboBox_separeePreFinalColor
            // 
            this.comboBox_separeePreFinalColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_separeePreFinalColor.FormattingEnabled = true;
            this.comboBox_separeePreFinalColor.Items.AddRange(new object[] {
            "Weiss",
            "Pink",
            "Gruen",
            "Blau",
            "Licht Aus"});
            this.comboBox_separeePreFinalColor.Location = new System.Drawing.Point(223, 121);
            this.comboBox_separeePreFinalColor.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_separeePreFinalColor.Name = "comboBox_separeePreFinalColor";
            this.comboBox_separeePreFinalColor.Size = new System.Drawing.Size(236, 28);
            this.comboBox_separeePreFinalColor.TabIndex = 58;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.label9.Location = new System.Drawing.Point(12, 126);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(170, 18);
            this.label9.TabIndex = 57;
            this.label9.Text = "Separee pre-final Farbe:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(404, 90);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 18);
            this.label32.TabIndex = 56;
            this.label32.Text = "sek.";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(12, 90);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(321, 18);
            this.label31.TabIndex = 56;
            this.label31.Text = "Verzögerung bei der Aktivierung der MoneyGun";
            // 
            // MoneyGunDelay
            // 
            this.MoneyGunDelay.BackColor = System.Drawing.Color.Gainsboro;
            this.MoneyGunDelay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MoneyGunDelay.DecimalPlaces = 1;
            this.MoneyGunDelay.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.MoneyGunDelay.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.MoneyGunDelay.Location = new System.Drawing.Point(333, 89);
            this.MoneyGunDelay.Margin = new System.Windows.Forms.Padding(4);
            this.MoneyGunDelay.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.MoneyGunDelay.Name = "MoneyGunDelay";
            this.MoneyGunDelay.Size = new System.Drawing.Size(72, 22);
            this.MoneyGunDelay.TabIndex = 56;
            this.MoneyGunDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MoneyGunDelay.Value = new decimal(new int[] {
            105,
            0,
            0,
            65536});
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Ivory;
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(361, 31);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(44, 50);
            this.button19.TabIndex = 28;
            this.button19.TabStop = false;
            this.button19.Tag = "preG_SecretC_w";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Red;
            this.button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(223, 31);
            this.button24.Margin = new System.Windows.Forms.Padding(4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(44, 50);
            this.button24.TabIndex = 25;
            this.button24.TabStop = false;
            this.button24.Tag = "preG_SecretC_r";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Yellow;
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(315, 31);
            this.button25.Margin = new System.Windows.Forms.Padding(4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(44, 50);
            this.button25.TabIndex = 23;
            this.button25.TabStop = false;
            this.button25.Tag = "preG_SecretC_y";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.label43.Location = new System.Drawing.Point(8, 47);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(207, 18);
            this.label43.TabIndex = 24;
            this.label43.Text = "Geheime Korridorbeleuchtung";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Magenta;
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(269, 31);
            this.button23.Margin = new System.Windows.Forms.Padding(4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(44, 50);
            this.button23.TabIndex = 26;
            this.button23.TabStop = false;
            this.button23.Tag = "preG_SecretC_p";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Gray;
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(407, 31);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(52, 50);
            this.button21.TabIndex = 29;
            this.button21.TabStop = false;
            this.button21.Tag = "preG_SecretC_off";
            this.button21.Text = "AUS";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.LaunchRoutineForButton_ForServiceTeam);
            // 
            // groupBox16
            // 
            this.groupBox16.BackColor = System.Drawing.Color.Transparent;
            this.groupBox16.Controls.Add(this.dataGridRiddles);
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(8, 513);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox16.Size = new System.Drawing.Size(1896, 322);
            this.groupBox16.TabIndex = 10;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Erweiterte Details";
            // 
            // dataGridRiddles
            // 
            this.dataGridRiddles.AllowUserToAddRows = false;
            this.dataGridRiddles.AllowUserToDeleteRows = false;
            this.dataGridRiddles.AllowUserToResizeRows = false;
            this.dataGridRiddles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridRiddles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridRiddles.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dataGridRiddles.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridRiddles.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.dataGridRiddles.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.NullValue = "No Data";
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridRiddles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridRiddles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridRiddles.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridRiddles.Location = new System.Drawing.Point(7, 25);
            this.dataGridRiddles.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridRiddles.MinimumSize = new System.Drawing.Size(1450, 250);
            this.dataGridRiddles.MultiSelect = false;
            this.dataGridRiddles.Name = "dataGridRiddles";
            this.dataGridRiddles.ReadOnly = true;
            this.dataGridRiddles.RowHeadersVisible = false;
            this.dataGridRiddles.RowHeadersWidth = 60;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridRiddles.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridRiddles.RowTemplate.ReadOnly = true;
            this.dataGridRiddles.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridRiddles.Size = new System.Drawing.Size(1450, 265);
            this.dataGridRiddles.TabIndex = 0;
            this.dataGridRiddles.TabStop = false;
            this.dataGridRiddles.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Debug
            // 
            this.Debug.AutoSize = true;
            this.Debug.Location = new System.Drawing.Point(259, 490);
            this.Debug.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Debug.Name = "Debug";
            this.Debug.Size = new System.Drawing.Size(0, 20);
            this.Debug.TabIndex = 10;
            // 
            // groupBoxElectronicsSettings
            // 
            this.groupBoxElectronicsSettings.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBoxElectronicsSettings.Controls.Add(this.label2);
            this.groupBoxElectronicsSettings.Controls.Add(this.button4);
            this.groupBoxElectronicsSettings.Controls.Add(this.button1);
            this.groupBoxElectronicsSettings.Controls.Add(this.COMportsList);
            this.groupBoxElectronicsSettings.Controls.Add(this.refreshCOM);
            this.groupBoxElectronicsSettings.Controls.Add(this.ButtonCOM);
            this.groupBoxElectronicsSettings.Controls.Add(this.label4);
            this.groupBoxElectronicsSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxElectronicsSettings.Location = new System.Drawing.Point(8, 9);
            this.groupBoxElectronicsSettings.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxElectronicsSettings.Name = "groupBoxElectronicsSettings";
            this.groupBoxElectronicsSettings.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxElectronicsSettings.Size = new System.Drawing.Size(879, 180);
            this.groupBoxElectronicsSettings.TabIndex = 3;
            this.groupBoxElectronicsSettings.TabStop = false;
            this.groupBoxElectronicsSettings.Text = "Elektronik";
            this.groupBoxElectronicsSettings.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(525, 48);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(349, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Optionen zurücksetzen (mit Bedacht einsetzen):";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SaddleBrown;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(688, 90);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 74);
            this.button4.TabIndex = 14;
            this.button4.TabStop = false;
            this.button4.Text = "Master-Antenne Reset";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkOrange;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(529, 90);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 74);
            this.button1.TabIndex = 12;
            this.button1.TabStop = false;
            this.button1.Text = "Netzwerk zurücksetzen";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // COMportsList
            // 
            this.COMportsList.FormattingEnabled = true;
            this.COMportsList.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "6+"});
            this.COMportsList.Location = new System.Drawing.Point(221, 44);
            this.COMportsList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.COMportsList.Name = "COMportsList";
            this.COMportsList.Size = new System.Drawing.Size(101, 28);
            this.COMportsList.TabIndex = 11;
            // 
            // refreshCOM
            // 
            this.refreshCOM.BackColor = System.Drawing.Color.WhiteSmoke;
            this.refreshCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshCOM.Location = new System.Drawing.Point(329, 39);
            this.refreshCOM.Margin = new System.Windows.Forms.Padding(4);
            this.refreshCOM.Name = "refreshCOM";
            this.refreshCOM.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.refreshCOM.Size = new System.Drawing.Size(145, 38);
            this.refreshCOM.TabIndex = 9;
            this.refreshCOM.TabStop = false;
            this.refreshCOM.Text = "Aktualisieren";
            this.refreshCOM.UseVisualStyleBackColor = false;
            this.refreshCOM.Click += new System.EventHandler(this.refreshCOM_Click);
            // 
            // ButtonCOM
            // 
            this.ButtonCOM.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.ButtonCOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonCOM.Location = new System.Drawing.Point(23, 90);
            this.ButtonCOM.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonCOM.Name = "ButtonCOM";
            this.ButtonCOM.Size = new System.Drawing.Size(451, 74);
            this.ButtonCOM.TabIndex = 4;
            this.ButtonCOM.TabStop = false;
            this.ButtonCOM.Text = "Verbindung herstellen";
            this.ButtonCOM.UseVisualStyleBackColor = false;
            this.ButtonCOM.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 48);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(197, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Kommunikationsanschluss";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // masterNodeHealth
            // 
            this.masterNodeHealth.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.masterNodeHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.masterNodeHealth.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.masterNodeHealth.Location = new System.Drawing.Point(1653, 163);
            this.masterNodeHealth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.masterNodeHealth.Name = "masterNodeHealth";
            this.masterNodeHealth.Size = new System.Drawing.Size(236, 20);
            this.masterNodeHealth.TabIndex = 15;
            this.masterNodeHealth.Text = "Keine Daten";
            this.masterNodeHealth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.masterNodeHealth.TextChanged += new System.EventHandler(this.masterNodeHealth_TextChanged);
            // 
            // TotalPacket_label
            // 
            this.TotalPacket_label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TotalPacket_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.TotalPacket_label.Location = new System.Drawing.Point(1653, 184);
            this.TotalPacket_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TotalPacket_label.Name = "TotalPacket_label";
            this.TotalPacket_label.Size = new System.Drawing.Size(236, 20);
            this.TotalPacket_label.TabIndex = 23;
            this.TotalPacket_label.Text = "Keine Daten";
            this.TotalPacket_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(1488, 184);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(159, 20);
            this.label40.TabIndex = 22;
            this.label40.Text = "Empfangene Pakete:";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(1488, 163);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(149, 20);
            this.label24.TabIndex = 7;
            this.label24.Text = "Serial Verzögerung:";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // Music_finale
            // 
            this.Music_finale.BackColor = System.Drawing.Color.LightGray;
            this.Music_finale.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Music_finale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Music_finale.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.Music_finale.Location = new System.Drawing.Point(25, 523);
            this.Music_finale.Margin = new System.Windows.Forms.Padding(4);
            this.Music_finale.Name = "Music_finale";
            this.Music_finale.Size = new System.Drawing.Size(352, 43);
            this.Music_finale.TabIndex = 27;
            this.Music_finale.TabStop = false;
            this.Music_finale.Tag = "Music_finale";
            this.Music_finale.Text = "Finale (End of the Game)";
            this.Music_finale.UseVisualStyleBackColor = false;
            this.Music_finale.Click += new System.EventHandler(this.Music_finale_Click);
            // 
            // Music_strip
            // 
            this.Music_strip.BackColor = System.Drawing.Color.LightGray;
            this.Music_strip.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Music_strip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Music_strip.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.Music_strip.Location = new System.Drawing.Point(25, 478);
            this.Music_strip.Margin = new System.Windows.Forms.Padding(4);
            this.Music_strip.Name = "Music_strip";
            this.Music_strip.Size = new System.Drawing.Size(352, 43);
            this.Music_strip.TabIndex = 26;
            this.Music_strip.TabStop = false;
            this.Music_strip.Tag = "Music_strip";
            this.Music_strip.Text = "Strippmodus (Separee riddle)";
            this.Music_strip.UseVisualStyleBackColor = false;
            this.Music_strip.Click += new System.EventHandler(this.Music_strip_Click);
            // 
            // Music_Atmo2
            // 
            this.Music_Atmo2.BackColor = System.Drawing.Color.LightGray;
            this.Music_Atmo2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Music_Atmo2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Music_Atmo2.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.Music_Atmo2.Location = new System.Drawing.Point(25, 432);
            this.Music_Atmo2.Margin = new System.Windows.Forms.Padding(4);
            this.Music_Atmo2.Name = "Music_Atmo2";
            this.Music_Atmo2.Size = new System.Drawing.Size(352, 43);
            this.Music_Atmo2.TabIndex = 25;
            this.Music_Atmo2.TabStop = false;
            this.Music_Atmo2.Tag = "Music_Atmo2";
            this.Music_Atmo2.Text = "Atmo2 (After Stopptanz)";
            this.Music_Atmo2.UseVisualStyleBackColor = false;
            this.Music_Atmo2.Click += new System.EventHandler(this.Music_Atmo2_Click);
            // 
            // Music_Stopptanz
            // 
            this.Music_Stopptanz.BackColor = System.Drawing.Color.LightGray;
            this.Music_Stopptanz.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Music_Stopptanz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Music_Stopptanz.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.Music_Stopptanz.Location = new System.Drawing.Point(25, 386);
            this.Music_Stopptanz.Margin = new System.Windows.Forms.Padding(4);
            this.Music_Stopptanz.Name = "Music_Stopptanz";
            this.Music_Stopptanz.Size = new System.Drawing.Size(352, 43);
            this.Music_Stopptanz.TabIndex = 24;
            this.Music_Stopptanz.TabStop = false;
            this.Music_Stopptanz.Tag = "Music_Stopptanz";
            this.Music_Stopptanz.Text = "Stopptanz (Stopptanze riddle)";
            this.Music_Stopptanz.UseVisualStyleBackColor = false;
            this.Music_Stopptanz.Click += new System.EventHandler(this.Music_Stopptanz_Click);
            // 
            // Music_Atmo1
            // 
            this.Music_Atmo1.BackColor = System.Drawing.Color.LightGray;
            this.Music_Atmo1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.Music_Atmo1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Music_Atmo1.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.Music_Atmo1.Location = new System.Drawing.Point(25, 341);
            this.Music_Atmo1.Margin = new System.Windows.Forms.Padding(4);
            this.Music_Atmo1.Name = "Music_Atmo1";
            this.Music_Atmo1.Size = new System.Drawing.Size(352, 43);
            this.Music_Atmo1.TabIndex = 23;
            this.Music_Atmo1.TabStop = false;
            this.Music_Atmo1.Tag = "Music_Atmo1";
            this.Music_Atmo1.Text = "Atmo1 (From the start)";
            this.Music_Atmo1.UseVisualStyleBackColor = false;
            this.Music_Atmo1.Click += new System.EventHandler(this.Music_Atmo1_Click);
            // 
            // startButton
            // 
            this.startButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.startButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.startButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startButton.Location = new System.Drawing.Point(1492, 208);
            this.startButton.Margin = new System.Windows.Forms.Padding(4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(397, 50);
            this.startButton.TabIndex = 10;
            this.startButton.TabStop = false;
            this.startButton.Text = "Spiel starten";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // SessionRunningTime
            // 
            this.SessionRunningTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SessionRunningTime.AutoSize = true;
            this.SessionRunningTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SessionRunningTime.Location = new System.Drawing.Point(1582, 94);
            this.SessionRunningTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SessionRunningTime.Name = "SessionRunningTime";
            this.SessionRunningTime.Size = new System.Drawing.Size(220, 55);
            this.SessionRunningTime.TabIndex = 12;
            this.SessionRunningTime.Text = "00:00:00";
            this.SessionRunningTime.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.progressBar_musicChange);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.FadeAtStart_mins);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.checkBox_FadeAtStart);
            this.groupBox2.Controls.Add(this.checkBox_fadeEffect);
            this.groupBox2.Controls.Add(this.FadeAtStart_secs);
            this.groupBox2.Controls.Add(this.FadeEffect_delay);
            this.groupBox2.Controls.Add(this.label_nextSong_delay);
            this.groupBox2.Controls.Add(this.label_nextSong);
            this.groupBox2.Controls.Add(this.label_track);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label_PlaybackState);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.checkBox_manualControl);
            this.groupBox2.Controls.Add(this.playMusic);
            this.groupBox2.Controls.Add(this.pauseMusic);
            this.groupBox2.Controls.Add(this.Music_finale);
            this.groupBox2.Controls.Add(this.Music_Atmo1);
            this.groupBox2.Controls.Add(this.Music_Stopptanz);
            this.groupBox2.Controls.Add(this.Music_Atmo2);
            this.groupBox2.Controls.Add(this.Music_strip);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(1494, 260);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(397, 681);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Musik Control";
            // 
            // progressBar_musicChange
            // 
            this.progressBar_musicChange.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.progressBar_musicChange.Location = new System.Drawing.Point(244, 591);
            this.progressBar_musicChange.Margin = new System.Windows.Forms.Padding(4);
            this.progressBar_musicChange.Name = "progressBar_musicChange";
            this.progressBar_musicChange.Size = new System.Drawing.Size(133, 28);
            this.progressBar_musicChange.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar_musicChange.TabIndex = 56;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(21, 570);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(168, 18);
            this.label44.TabIndex = 73;
            this.label44.Text = "Musik Delay countdown:";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(331, 206);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 18);
            this.label46.TabIndex = 72;
            this.label46.Text = "sek.";
            // 
            // FadeAtStart_mins
            // 
            this.FadeAtStart_mins.BackColor = System.Drawing.Color.LightGray;
            this.FadeAtStart_mins.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FadeAtStart_mins.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.FadeAtStart_mins.Location = new System.Drawing.Point(244, 230);
            this.FadeAtStart_mins.Margin = new System.Windows.Forms.Padding(4);
            this.FadeAtStart_mins.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.FadeAtStart_mins.Name = "FadeAtStart_mins";
            this.FadeAtStart_mins.Size = new System.Drawing.Size(72, 22);
            this.FadeAtStart_mins.TabIndex = 71;
            this.FadeAtStart_mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FadeAtStart_mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(248, 206);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(36, 18);
            this.label29.TabIndex = 67;
            this.label29.Text = "min.";
            // 
            // checkBox_FadeAtStart
            // 
            this.checkBox_FadeAtStart.AutoSize = true;
            this.checkBox_FadeAtStart.Checked = true;
            this.checkBox_FadeAtStart.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_FadeAtStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_FadeAtStart.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.checkBox_FadeAtStart.Location = new System.Drawing.Point(8, 226);
            this.checkBox_FadeAtStart.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox_FadeAtStart.Name = "checkBox_FadeAtStart";
            this.checkBox_FadeAtStart.Size = new System.Drawing.Size(140, 22);
            this.checkBox_FadeAtStart.TabIndex = 70;
            this.checkBox_FadeAtStart.Text = "Start music delay\r\n";
            this.checkBox_FadeAtStart.UseVisualStyleBackColor = true;
            // 
            // checkBox_fadeEffect
            // 
            this.checkBox_fadeEffect.AutoSize = true;
            this.checkBox_fadeEffect.Checked = true;
            this.checkBox_fadeEffect.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_fadeEffect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_fadeEffect.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.checkBox_fadeEffect.Location = new System.Drawing.Point(8, 258);
            this.checkBox_fadeEffect.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox_fadeEffect.Name = "checkBox_fadeEffect";
            this.checkBox_fadeEffect.Size = new System.Drawing.Size(135, 22);
            this.checkBox_fadeEffect.TabIndex = 65;
            this.checkBox_fadeEffect.Text = "Track fade in/out";
            this.checkBox_fadeEffect.UseVisualStyleBackColor = true;
            // 
            // FadeAtStart_secs
            // 
            this.FadeAtStart_secs.BackColor = System.Drawing.Color.LightGray;
            this.FadeAtStart_secs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FadeAtStart_secs.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.FadeAtStart_secs.Location = new System.Drawing.Point(324, 231);
            this.FadeAtStart_secs.Margin = new System.Windows.Forms.Padding(4);
            this.FadeAtStart_secs.Maximum = new decimal(new int[] {
            61,
            0,
            0,
            0});
            this.FadeAtStart_secs.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.FadeAtStart_secs.Name = "FadeAtStart_secs";
            this.FadeAtStart_secs.Size = new System.Drawing.Size(72, 22);
            this.FadeAtStart_secs.TabIndex = 68;
            this.FadeAtStart_secs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FadeAtStart_secs.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.FadeAtStart_secs.ValueChanged += new System.EventHandler(this.FadeAtStart_secs_ValueChanged);
            // 
            // FadeEffect_delay
            // 
            this.FadeEffect_delay.BackColor = System.Drawing.Color.LightGray;
            this.FadeEffect_delay.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FadeEffect_delay.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.FadeEffect_delay.Location = new System.Drawing.Point(323, 262);
            this.FadeEffect_delay.Margin = new System.Windows.Forms.Padding(4);
            this.FadeEffect_delay.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.FadeEffect_delay.Name = "FadeEffect_delay";
            this.FadeEffect_delay.Size = new System.Drawing.Size(72, 22);
            this.FadeEffect_delay.TabIndex = 66;
            this.FadeEffect_delay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FadeEffect_delay.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label_nextSong_delay
            // 
            this.label_nextSong_delay.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nextSong_delay.Location = new System.Drawing.Point(244, 568);
            this.label_nextSong_delay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_nextSong_delay.Name = "label_nextSong_delay";
            this.label_nextSong_delay.Size = new System.Drawing.Size(129, 22);
            this.label_nextSong_delay.TabIndex = 64;
            this.label_nextSong_delay.Text = "0 sek.";
            this.label_nextSong_delay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_nextSong
            // 
            this.label_nextSong.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nextSong.Location = new System.Drawing.Point(228, 623);
            this.label_nextSong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_nextSong.Name = "label_nextSong";
            this.label_nextSong.Size = new System.Drawing.Size(149, 22);
            this.label_nextSong.TabIndex = 59;
            this.label_nextSong.Text = "None";
            this.label_nextSong.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_track
            // 
            this.label_track.AutoSize = true;
            this.label_track.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_track.Location = new System.Drawing.Point(284, 153);
            this.label_track.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_track.Name = "label_track";
            this.label_track.Size = new System.Drawing.Size(70, 18);
            this.label_track.TabIndex = 53;
            this.label_track.Text = "Unknown";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(13, 153);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 18);
            this.label30.TabIndex = 52;
            this.label30.Text = "Track:";
            // 
            // label_PlaybackState
            // 
            this.label_PlaybackState.AutoSize = true;
            this.label_PlaybackState.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PlaybackState.Location = new System.Drawing.Point(284, 126);
            this.label_PlaybackState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_PlaybackState.Name = "label_PlaybackState";
            this.label_PlaybackState.Size = new System.Drawing.Size(70, 18);
            this.label_PlaybackState.TabIndex = 51;
            this.label_PlaybackState.Text = "Unknown";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(21, 598);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(139, 18);
            this.label47.TabIndex = 52;
            this.label47.Text = "Musik Veränderung:";
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Bahnschrift", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(13, 126);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(92, 22);
            this.label28.TabIndex = 49;
            this.label28.Text = "Status:";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBox_manualControl
            // 
            this.checkBox_manualControl.AutoSize = true;
            this.checkBox_manualControl.Checked = true;
            this.checkBox_manualControl.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_manualControl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox_manualControl.Font = new System.Drawing.Font("Bahnschrift", 11.25F);
            this.checkBox_manualControl.Location = new System.Drawing.Point(8, 293);
            this.checkBox_manualControl.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox_manualControl.Name = "checkBox_manualControl";
            this.checkBox_manualControl.Size = new System.Drawing.Size(224, 22);
            this.checkBox_manualControl.TabIndex = 50;
            this.checkBox_manualControl.Text = "Rätsel kontrollieren die Musik";
            this.checkBox_manualControl.UseVisualStyleBackColor = true;
            // 
            // playMusic
            // 
            this.playMusic.BackColor = System.Drawing.Color.Transparent;
            this.playMusic.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.play_solid;
            this.playMusic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.playMusic.FlatAppearance.BorderSize = 0;
            this.playMusic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playMusic.Location = new System.Drawing.Point(136, 59);
            this.playMusic.Margin = new System.Windows.Forms.Padding(4);
            this.playMusic.Name = "playMusic";
            this.playMusic.Size = new System.Drawing.Size(53, 60);
            this.playMusic.TabIndex = 4;
            this.playMusic.Tag = "Music_play";
            this.playMusic.UseVisualStyleBackColor = false;
            this.playMusic.Click += new System.EventHandler(this.playMusic_Click);
            // 
            // pauseMusic
            // 
            this.pauseMusic.BackColor = System.Drawing.Color.Transparent;
            this.pauseMusic.BackgroundImage = global::BuggieBungalow_Pult.Properties.Resources.pause_solid;
            this.pauseMusic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pauseMusic.FlatAppearance.BorderSize = 0;
            this.pauseMusic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pauseMusic.Location = new System.Drawing.Point(213, 59);
            this.pauseMusic.Margin = new System.Windows.Forms.Padding(4);
            this.pauseMusic.Name = "pauseMusic";
            this.pauseMusic.Size = new System.Drawing.Size(53, 60);
            this.pauseMusic.TabIndex = 17;
            this.pauseMusic.Tag = "Music_pause";
            this.pauseMusic.UseVisualStyleBackColor = false;
            this.pauseMusic.Click += new System.EventHandler(this.pauseMusic_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::BuggieBungalow_Pult.Properties.Resources.download_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(1650, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(84, 86);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(1359, 869);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 14);
            this.label41.TabIndex = 74;
            this.label41.Text = "Powered by";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(1383, 883);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(89, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // MainScreen
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1904, 921);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.SessionRunningTime);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.masterNodeHealth);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.TotalPacket_label);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1920, 960);
            this.MinimumSize = new System.Drawing.Size(1918, 960);
            this.Name = "MainScreen";
            this.Text = "BB Control panel";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.Shown += new System.EventHandler(this.MainScreen_Shown);
            this.tabControl1.ResumeLayout(false);
            this.onGame.ResumeLayout(false);
            this.onGame.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_4Drinks)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_Stopptanz)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_wasserhahn)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_sparkatsen)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_Separee)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_workSchedules)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GM_range_jukebox)).EndInit();
            this.preGame.ResumeLayout(false);
            this.preGame.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoneyGunDelay)).EndInit();
            this.groupBox16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRiddles)).EndInit();
            this.groupBoxElectronicsSettings.ResumeLayout(false);
            this.groupBoxElectronicsSettings.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FadeAtStart_mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FadeAtStart_secs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FadeEffect_delay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage preGame;
        private System.Windows.Forms.TabPage onGame;
        private System.Windows.Forms.GroupBox groupBoxElectronicsSettings;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ButtonCOM;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label SessionRunningTime;
        private System.Windows.Forms.Button playMusic;
        private System.Windows.Forms.Button trafficLight_dance;
        private System.Windows.Forms.Button trafficLight_stop;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button solve_beerglasses;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label masterNodeHealth;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button refreshCOM;
        private System.Windows.Forms.ComboBox COMportsList;
        private System.Windows.Forms.Label Debug;
        private System.Windows.Forms.Button pauseMusic;
        private System.Windows.Forms.Button DancingMoves_dance3;
        private System.Windows.Forms.Button DancingMoves_dance2;
        private System.Windows.Forms.Button DancingMoves_dance1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox COMLog;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label NetChannel_label;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label SelfRepairs_label;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label TotalPacket_label;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label CorruptPacket_label;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lastPacket_label;
        private System.Windows.Forms.Label NodeResync_label;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label PacketsSent_label;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.DataGridView dataGridRiddles;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Music_finale;
        private System.Windows.Forms.Button Music_strip;
        private System.Windows.Forms.Button Music_Atmo2;
        private System.Windows.Forms.Button Music_Stopptanz;
        private System.Windows.Forms.Button Music_Atmo1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox checkBox_moneyGun;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox GM_range_4Drinks;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox CustomPacket;
        private System.Windows.Forms.Button button_SendCustomPacket;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox GM_range_Stopptanz;
        private System.Windows.Forms.PictureBox GM_range_wasserhahn;
        private System.Windows.Forms.PictureBox GM_range_sparkatsen;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox GM_range_Separee;
        private System.Windows.Forms.PictureBox GM_range_workSchedules;
        private System.Windows.Forms.PictureBox GM_range_jukebox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox_manualControl;
        private System.Windows.Forms.Label label_track;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label_PlaybackState;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown MoneyGunDelay;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label debuglabel;
        private System.Windows.Forms.ProgressBar progressBar_musicChange;
        private System.Windows.Forms.Label label_nextSong;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox comboBox_separeePreFinalColor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label_nextSong_delay;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown FadeAtStart_mins;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.CheckBox checkBox_FadeAtStart;
        private System.Windows.Forms.CheckBox checkBox_fadeEffect;
        private System.Windows.Forms.NumericUpDown FadeAtStart_secs;
        private System.Windows.Forms.NumericUpDown FadeEffect_delay;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label delay_4drinks;
        private System.Windows.Forms.Label delay_stoptanz;
        private System.Windows.Forms.Label delay_wasserhahn;
        private System.Windows.Forms.Label delay_sparkatchen;
        private System.Windows.Forms.Label delay_separee;
        private System.Windows.Forms.Label delay_schichtplan;
        private System.Windows.Forms.Label delay_jukebox;
    }
}

